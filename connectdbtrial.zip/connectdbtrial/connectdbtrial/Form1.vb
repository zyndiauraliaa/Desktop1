﻿Imports MySql.Data.MySqlClient

Public Class Form1
    ' Deklarasi variabel secara global
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader

    ' Fungsi untuk membuat koneksi ke database
    Sub Koneksi()
        conn = New MySqlConnection("server=localhost;user id=root;password=;database=dbtrial")
        Try
            conn.Open()
            MsgBox("Koneksi Berhasil")
        Catch myerror As MySqlException
            MsgBox("Error Koneksi: " & myerror.Message)
            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub

    ' Event ketika Button1 diklik untuk memuat data dari database
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Koneksi()
        ' Pastikan koneksi terbuka sebelum membuat command
        If conn.State = ConnectionState.Open Then
            Try
                ' Membuat command dengan query
                cmd = New MySqlCommand("SELECT * FROM tblbarang", conn)
                dr = cmd.ExecuteReader()

                ' Membaca data dari DataReader
                ListView1.Items.Clear() ' Bersihkan ListView sebelum menambahkan data baru
                While dr.Read()
                    Dim item As New ListViewItem(dr("Kode_Barang").ToString())
                    item.SubItems.Add(dr("Nama_Barang").ToString())
                    item.SubItems.Add(dr("Jenis").ToString())
                    item.SubItems.Add(dr("Satuan").ToString())
                    item.SubItems.Add(dr("Harga_Beli").ToString())
                    item.SubItems.Add(dr("Harga_Jual").ToString())
                    item.SubItems.Add(dr("Stock").ToString())

                    ' Menambahkan item ke ListView
                    ListView1.Items.Add(item)
                End While

                ' Menutup DataReader setelah selesai digunakan
                dr.Close()
            Catch ex As MySqlException
                MsgBox("Error saat mengambil data: " & ex.Message)
            Finally
                ' Menutup koneksi setelah selesai
                If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        End If
    End Sub

    ' Subrutin untuk membersihkan semua TextBox dan NumericUpDown pada form
    Private Sub btnBr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBr.Click
        ' Bersihkan TextBox dan NumericUpDown
        For Each ctr As Control In Me.Controls
            If TypeOf ctr Is TextBox Then
                ctr.Text = ""
            ElseIf TypeOf ctr Is NumericUpDown Then
                DirectCast(ctr, NumericUpDown).Value = 0
            End If
        Next
    End Sub

    ' Subrutin untuk menyimpan data ke database dan memperbarui ListView
    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        Try
            ' Periksa apakah koneksi sudah terbuka
            If conn Is Nothing OrElse conn.State = ConnectionState.Closed Then
                conn = New MySqlConnection("server=localhost;user id=root;password=;database=dbtrial")
                conn.Open()
            End If

            ' Menggunakan parameterized query untuk menghindari SQL Injection
            Dim query As String = "INSERT INTO tblbarang (Kode_Barang, Nama_Barang, Jenis, Satuan, Harga_Beli, Harga_Jual, Stock) VALUES (@kdBrg, @nmBrg, @jns, @satuan, @HB, @HJ, @stk)"
            cmd = New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@kdBrg", kdBrg.Text)
            cmd.Parameters.AddWithValue("@nmBrg", nmBrg.Text)
            cmd.Parameters.AddWithValue("@jns", jns.Text)
            cmd.Parameters.AddWithValue("@satuan", satuan.Text)
            cmd.Parameters.AddWithValue("@HB", HB.Value)
            cmd.Parameters.AddWithValue("@HJ", HJ.Value)
            cmd.Parameters.AddWithValue("@stk", stk.Value)

            ' Eksekusi perintah insert
            cmd.ExecuteNonQuery()

            MsgBox("Data berhasil disimpan!")

            ' Bersihkan ListView dan muat data terbaru setelah menambahkan data
            ListView1.Items.Clear()
            LoadDataFromDatabase()

        Catch ex As MySqlException
            MsgBox("Error saat menyimpan data: " & ex.Message)
        Finally
            ' Tutup koneksi
            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
            ' Bersihkan objek command
            If cmd IsNot Nothing Then
                cmd.Dispose()
            End If
        End Try
    End Sub

    ' Subrutin untuk memperbarui data di database
    Private Sub btnUbah_Click(sender As Object, e As EventArgs) Handles btnUbah.Click
        Try
            ' Pastikan ada item yang dipilih di ListView
            If ListView1.SelectedItems.Count = 0 Then
                MsgBox("Silakan pilih item yang ingin diubah.")
                Exit Sub
            End If

            ' Ambil Kode_Barang dari item yang dipilih
            Dim kodeBarang As String = ListView1.SelectedItems(0).SubItems(0).Text

            ' Periksa apakah koneksi sudah terbuka
            If conn Is Nothing OrElse conn.State = ConnectionState.Closed Then
                conn = New MySqlConnection("server=localhost;user id=root;password=;database=dbtrial")
                conn.Open()
            End If

            ' Perintah SQL untuk memperbarui data
            Dim query As String = "UPDATE tblbarang SET Nama_Barang = @nmBrg, Jenis = @jns, Satuan = @satuan, Harga_Beli = @HB, Harga_Jual = @HJ, Stock = @stk WHERE Kode_Barang = @kdBrg"
            cmd = New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@kdBrg", kodeBarang)
            cmd.Parameters.AddWithValue("@nmBrg", nmBrg.Text)
            cmd.Parameters.AddWithValue("@jns", jns.Text)
            cmd.Parameters.AddWithValue("@satuan", satuan.Text)
            cmd.Parameters.AddWithValue("@HB", HB.Value)
            cmd.Parameters.AddWithValue("@HJ", HJ.Value)
            cmd.Parameters.AddWithValue("@stk", stk.Value)

            ' Eksekusi query untuk memperbarui data
            cmd.ExecuteNonQuery()

            ' Pesan sukses
            MsgBox("Data berhasil diperbarui!")

            ' Bersihkan ListView dan muat ulang data
            ListView1.Items.Clear()
            LoadDataFromDatabase()

        Catch ex As MySqlException
            ' Tampilkan pesan error
            MsgBox("Error saat memperbarui data: " & ex.Message)
        Finally
            ' Tutup koneksi
            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
            ' Bersihkan objek command
            If cmd IsNot Nothing Then
                cmd.Dispose()
            End If
        End Try
    End Sub

    ' Subrutin untuk menghapus data dari database
    Private Sub btnHps_Click(sender As Object, e As EventArgs) Handles btnHps.Click
        Try
            ' Pastikan ada item yang dipilih di ListView
            If ListView1.SelectedItems.Count = 0 Then
                MsgBox("Silakan pilih item yang ingin dihapus.")
                Exit Sub
            End If

            ' Ambil Kode_Barang dari item yang dipilih
            Dim kodeBarang As String = ListView1.SelectedItems(0).SubItems(0).Text

            ' Konfirmasi penghapusan
            Dim result As DialogResult = MessageBox.Show("Apakah Anda yakin ingin menghapus data dengan kode barang: " & kodeBarang & "?", "Konfirmasi", MessageBoxButtons.YesNo)
            If result = DialogResult.No Then Exit Sub

            ' Periksa apakah koneksi sudah terbuka
            If conn Is Nothing OrElse conn.State = ConnectionState.Closed Then
                conn = New MySqlConnection("server=localhost;user id=root;password=;database=dbtrial")
                conn.Open()
            End If

            ' Perintah SQL untuk menghapus data
            Dim query As String = "DELETE FROM tblbarang WHERE Kode_Barang = @kdBrg"
            cmd = New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@kdBrg", kodeBarang)

            ' Eksekusi query untuk menghapus data
            cmd.ExecuteNonQuery()

            ' Pesan sukses
            MsgBox("Data berhasil dihapus!")

            ' Bersihkan ListView dan muat ulang data
            ListView1.Items.Clear()
            LoadDataFromDatabase()

        Catch ex As MySqlException
            ' Tampilkan pesan error
            MsgBox("Error saat menghapus data: " & ex.Message)
        Finally
            ' Tutup koneksi
            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
            ' Bersihkan objek command
            If cmd IsNot Nothing Then
                cmd.Dispose()
            End If
        End Try
    End Sub

    ' Fungsi untuk memuat data dari database ke ListView
    Private Sub LoadDataFromDatabase()
        Koneksi()
        If conn.State = ConnectionState.Open Then
            Try
                cmd = New MySqlCommand("SELECT * FROM tblbarang", conn)
                dr = cmd.ExecuteReader()
                ListView1.Items.Clear()
                While dr.Read()
                    Dim item As New ListViewItem(dr("Kode_Barang").ToString())
                    item.SubItems.Add(dr("Nama_Barang").ToString())
                    item.SubItems.Add(dr("Jenis").ToString())
                    item.SubItems.Add(dr("Satuan").ToString())
                    item.SubItems.Add(dr("Harga_Beli").ToString())
                    item.SubItems.Add(dr("Harga_Jual").ToString())
                    item.SubItems.Add(dr("Stock").ToString())
                    ListView1.Items.Add(item)
                End While
                dr.Close()
            Catch ex As MySqlException
                MsgBox("Error saat memuat data: " & ex.Message)
            Finally
                If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        End If
    End Sub
End Class