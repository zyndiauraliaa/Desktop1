﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Button1 = New Button()
        kdBrg = New TextBox()
        nmBrg = New TextBox()
        jns = New TextBox()
        satuan = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        HB = New NumericUpDown()
        HJ = New NumericUpDown()
        stk = New NumericUpDown()
        btnBr = New Button()
        btnSimpan = New Button()
        btnUbah = New Button()
        btnHps = New Button()
        ListView1 = New ListView()
        ColumnHeader1 = New ColumnHeader()
        ColumnHeader2 = New ColumnHeader()
        ColumnHeader3 = New ColumnHeader()
        ColumnHeader4 = New ColumnHeader()
        ColumnHeader5 = New ColumnHeader()
        ColumnHeader6 = New ColumnHeader()
        ColumnHeader7 = New ColumnHeader()
        CType(HB, ComponentModel.ISupportInitialize).BeginInit()
        CType(HJ, ComponentModel.ISupportInitialize).BeginInit()
        CType(stk, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(13, 171)
        Button1.Name = "Button1"
        Button1.Size = New Size(123, 38)
        Button1.TabIndex = 0
        Button1.Text = "tes"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' kdBrg
        ' 
        kdBrg.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        kdBrg.Location = New Point(164, 9)
        kdBrg.Name = "kdBrg"
        kdBrg.Size = New Size(168, 34)
        kdBrg.TabIndex = 0
        ' 
        ' nmBrg
        ' 
        nmBrg.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        nmBrg.Location = New Point(164, 49)
        nmBrg.Name = "nmBrg"
        nmBrg.Size = New Size(317, 34)
        nmBrg.TabIndex = 1
        ' 
        ' jns
        ' 
        jns.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        jns.Location = New Point(164, 89)
        jns.Name = "jns"
        jns.Size = New Size(168, 34)
        jns.TabIndex = 2
        ' 
        ' satuan
        ' 
        satuan.Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        satuan.Location = New Point(164, 129)
        satuan.Name = "satuan"
        satuan.Size = New Size(169, 34)
        satuan.TabIndex = 3
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(124, 28)
        Label1.TabIndex = 5
        Label1.Text = "Kode Barang"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(12, 47)
        Label2.Name = "Label2"
        Label2.Size = New Size(130, 28)
        Label2.TabIndex = 6
        Label2.Text = "Nama Barang"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(12, 88)
        Label3.Name = "Label3"
        Label3.Size = New Size(53, 28)
        Label3.TabIndex = 7
        Label3.Text = "Jenis"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(12, 128)
        Label4.Name = "Label4"
        Label4.Size = New Size(72, 28)
        Label4.TabIndex = 8
        Label4.Text = "Satuan"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(521, 9)
        Label5.Name = "Label5"
        Label5.Size = New Size(101, 28)
        Label5.TabIndex = 9
        Label5.Text = "Harga Beli"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(521, 47)
        Label6.Name = "Label6"
        Label6.Size = New Size(103, 28)
        Label6.TabIndex = 10
        Label6.Text = "Harga Jual"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(521, 88)
        Label7.Name = "Label7"
        Label7.Size = New Size(117, 28)
        Label7.TabIndex = 11
        Label7.Text = "Stok Barang"
        ' 
        ' HB
        ' 
        HB.Location = New Point(670, 12)
        HB.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        HB.Name = "HB"
        HB.Size = New Size(198, 34)
        HB.TabIndex = 4
        ' 
        ' HJ
        ' 
        HJ.Location = New Point(670, 52)
        HJ.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        HJ.Name = "HJ"
        HJ.Size = New Size(198, 34)
        HJ.TabIndex = 5
        ' 
        ' stk
        ' 
        stk.Location = New Point(670, 92)
        stk.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        stk.Name = "stk"
        stk.Size = New Size(198, 34)
        stk.TabIndex = 6
        ' 
        ' btnBr
        ' 
        btnBr.Location = New Point(454, 149)
        btnBr.Name = "btnBr"
        btnBr.Size = New Size(91, 60)
        btnBr.TabIndex = 7
        btnBr.Text = "Baru"
        btnBr.UseVisualStyleBackColor = True
        ' 
        ' btnSimpan
        ' 
        btnSimpan.Location = New Point(561, 149)
        btnSimpan.Name = "btnSimpan"
        btnSimpan.Size = New Size(93, 60)
        btnSimpan.TabIndex = 8
        btnSimpan.Text = "Simpan"
        btnSimpan.UseVisualStyleBackColor = True
        ' 
        ' btnUbah
        ' 
        btnUbah.Location = New Point(670, 149)
        btnUbah.Name = "btnUbah"
        btnUbah.Size = New Size(93, 60)
        btnUbah.TabIndex = 9
        btnUbah.Text = "Ubah"
        btnUbah.UseVisualStyleBackColor = True
        ' 
        ' btnHps
        ' 
        btnHps.Location = New Point(778, 149)
        btnHps.Name = "btnHps"
        btnHps.Size = New Size(93, 60)
        btnHps.TabIndex = 10
        btnHps.Text = "Hapus"
        btnHps.UseVisualStyleBackColor = True
        ' 
        ' ListView1
        ' 
        ListView1.Columns.AddRange(New ColumnHeader() {ColumnHeader1, ColumnHeader2, ColumnHeader3, ColumnHeader4, ColumnHeader5, ColumnHeader6, ColumnHeader7})
        ListView1.FullRowSelect = True
        ListView1.Location = New Point(12, 234)
        ListView1.Name = "ListView1"
        ListView1.Size = New Size(859, 364)
        ListView1.TabIndex = 11
        ListView1.UseCompatibleStateImageBehavior = False
        ListView1.View = View.Details
        ' 
        ' ColumnHeader1
        ' 
        ColumnHeader1.Text = "Kode Barang"
        ColumnHeader1.Width = 120
        ' 
        ' ColumnHeader2
        ' 
        ColumnHeader2.Text = "Nama Barang"
        ColumnHeader2.Width = 220
        ' 
        ' ColumnHeader3
        ' 
        ColumnHeader3.Text = "Jenis"
        ColumnHeader3.Width = 100
        ' 
        ' ColumnHeader4
        ' 
        ColumnHeader4.Text = "Satuan"
        ColumnHeader4.Width = 100
        ' 
        ' ColumnHeader5
        ' 
        ColumnHeader5.Text = "Beli"
        ColumnHeader5.Width = 100
        ' 
        ' ColumnHeader6
        ' 
        ColumnHeader6.Text = "Jual"
        ColumnHeader6.Width = 100
        ' 
        ' ColumnHeader7
        ' 
        ColumnHeader7.Text = "Stok"
        ColumnHeader7.Width = 100
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(11F, 28F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(885, 610)
        Controls.Add(ListView1)
        Controls.Add(btnHps)
        Controls.Add(btnUbah)
        Controls.Add(btnSimpan)
        Controls.Add(btnBr)
        Controls.Add(stk)
        Controls.Add(HJ)
        Controls.Add(HB)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(satuan)
        Controls.Add(jns)
        Controls.Add(nmBrg)
        Controls.Add(kdBrg)
        Controls.Add(Button1)
        Font = New Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Name = "Form1"
        Text = "Form1"
        CType(HB, ComponentModel.ISupportInitialize).EndInit()
        CType(HJ, ComponentModel.ISupportInitialize).EndInit()
        CType(stk, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents kdBrg As TextBox
    Friend WithEvents nmBrg As TextBox
    Friend WithEvents jns As TextBox
    Friend WithEvents satuan As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents HB As NumericUpDown
    Friend WithEvents HJ As NumericUpDown
    Friend WithEvents stk As NumericUpDown
    Friend WithEvents btnBr As Button
    Friend WithEvents btnSimpan As Button
    Friend WithEvents btnUbah As Button
    Friend WithEvents btnHps As Button
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader6 As ColumnHeader
    Friend WithEvents ColumnHeader7 As ColumnHeader

End Class
